from sparkmagic.magics.remotesparkmagics import *
