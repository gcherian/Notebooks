LOGGING_CONFIG_CLASS_NAME = u"hdijupyterutils.filehandler.MagicsFileHandler"

EVENTS_HANDLER_CLASS_NAME = u"hdijupyterutils.eventshandler.EventsHandler"
INSTANCE_ID = "InstanceId"
TIMESTAMP = "Timestamp"
EVENT_NAME = "EventName"
